﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsRadyjko
{ 
   
    public partial class Form1 : Form
    {
        public class kanal
        {
          public  string name { get; set; }
          public  string song { get; set; }
           public string channelNumber { get; set; }
        }
        kanal Kanal1 = new kanal()
        {
            name = "RadioZet",
            song = "MocneBity",
            channelNumber = "1"
        };
        kanal Kanal2 = new kanal()
        {
            name = "Kopernikus",
            song = "Eine kleine nacht musik",
            channelNumber = "2"
        };
        kanal Kanal3 = new kanal()
        {
            name = "SlonceRMF",
            song = "Naturalna",
            channelNumber = "3"
        };
        int tempCheck;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = Kanal1.name;
            label2.Text = Kanal1.song;
            label3.Text = Kanal1.channelNumber;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = Kanal2.name;
            label2.Text = Kanal2.song;
            label3.Text = Kanal2.channelNumber;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = Kanal3.name;
            label2.Text = Kanal3.song;
            label3.Text = Kanal3.channelNumber;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
           
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label7.Text = "Glosnosc: " + progressBar1.Value + "%";
            progressBar1.Value = trackBar1.Value;
            checkBox1.Checked = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label7.Text = "Glosnosc: " + progressBar1.Value + "%";
          
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                tempCheck = progressBar1.Value;
                progressBar1.Value = 0;
                label7.Text = "Glosnosc: " + progressBar1.Value + "%";
            }
            else
                    {
                         progressBar1.Value = tempCheck;
                         label7.Text = "Glosnosc: " + progressBar1.Value + "%";
                    }


        }
    }
}
